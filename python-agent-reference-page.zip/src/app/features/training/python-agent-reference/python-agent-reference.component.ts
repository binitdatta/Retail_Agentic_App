import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-training-python-agent-reference',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './python-agent-reference.component.html'
})
export class TrainingPythonAgentReferenceComponent {}
